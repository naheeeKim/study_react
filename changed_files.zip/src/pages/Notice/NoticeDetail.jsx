import React ,{useEffect, useState}from "react";
import "../../style/pages/notice/notice.scss";
import axios from 'axios';

export default function NoticeDetail(){

    return (
        <>
            <div className="notice-detail">
                <div className="notice-top">
                    <strong className="tit"></strong>
                </div>
                <div className="notice-content">
                    
                </div>
            </div>
        </>
    )
}